//--------------------------------PassWord Toggle--------------------------//
const currentPassword = document.querySelector('.current-password');
const newPassword = document.querySelector('.new-password');
const confirmPassword = document.querySelector('.confirm-password');
const togglePasswordButtons = document.querySelectorAll('.toggle-password');
togglePasswordButtons.forEach(button => {
  button.addEventListener('click', () => {
    const passwordField = button.previousElementSibling;
    const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordField.setAttribute('type', type);
    button.classList.toggle('fa-eye-slash');
  });
});

//---------------------------------Save---------------------------------//
document.getElementById("save-btn").addEventListener("click", function() {
    const firstName = document.querySelector('input[name="first_name"]').value;
    const lastName = document.querySelector('input[name="last_name"]').value;
    const email = document.querySelector('input[name="email"]').value;
    document.getElementById("user-name").textContent = `${firstName} ${lastName}`;
    document.getElementById("user-email").textContent = `${email}`;
  });

//---------------------------------Upload image-----------------------//
let profilePic=document.getElementById("profile-pic");
let inputFile=document.getElementById("input-file");
inputFile.onchange=function(){
    profilePic.src=URL.createObjectURL(inputFile.files[0]);
}